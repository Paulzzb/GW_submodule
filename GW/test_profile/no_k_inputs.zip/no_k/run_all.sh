#!/usr/bin/env bash
# Single-Gamma (1x1x1 k) Silicon: QE -> pw2bgw -> epsilon -> sigma. All I/O in this directory.
set -euo pipefail
cd "$(dirname "$0")"
PW=/home/zhengbang/bin/pw.x
PW2BGW=/home/zhengbang/bin/pw2bgw.x
BGW=/home/zhengbang/soft/BerkeleyGW-3.0.1-fresh/BerkeleyGW-3.0.1/bin

"$PW" < scf.in > scf.out
"$PW" < wfn.in > wfn.out
"$PW2BGW" < pw2bgw.in > pw2bgw.out
ln -sf WFN WFN_inner
ln -sf WFN WFN_outer
ln -sf VXC VXC2
"$PW" < wfnq.in > wfnq.out
"$PW2BGW" < pw2bgw_wfnq.in > pw2bgw_wfnq.out

# BerkeleyGW here is linked to Intel MPI; avoid bare epsilon/sigma without mpirun.
# shellcheck source=/dev/null
source /opt/intel/oneapi/setvars.sh --force
export I_MPI_FABRICS=shm
mpirun -np 1 "$BGW/epsilon.cplx.x" > epsilon.out
mpirun -np 2 "$BGW/sigma.cplx.x" > sigma.out

echo "--- Si.save HDF5 check (see check_si_save_hdf5.py; exit 0 = HDF5 data files) ---"
python3 check_si_save_hdf5.py Si.save --pw-x "$PW" || true

echo "Done. Check epsilon.out and sigma.out for 'Job Done'."
